What's around är en app som ska ge dig så mycket information som möjligt om ett visst område. Du kan utgå ifrån din nuvarande position eller med hjälp av ett sökfält hitta valfri plats.

När du valt din plats så visas en överblicksby av området du befinner dig i som visar aktuellt väder, din position på en karta och butiker och restauranger i närheten.

Företagen som finns i närheten listas och om du vill veta mer så kan du klicka på respektive företag för att få upp deras position, kontaktuppgifter, öppettider och recensioner mm.

Vädret som visas i överblicksvyn är nuvarande väder och morgondagens väder. Vill man se mer i detalj hur vädret kommer se ut under dagen så finns en dropdown meny som listar prognosen timme för timme.
